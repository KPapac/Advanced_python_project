Enigma

This is an attempt to simulate the enigma machine in python.

Installation:


Usage:
from enigma\_kostas.enigma\_run import enigma\_encrypt
enigma\_encrypt("Hello World", "123")

