Enigma

This is an attempt to simulate the enigma machine in python.

Installation:
pip3 install uu-enigma-kostas

Usage:
from enigma\_kostas.enigma\_run import enigma\_encrypt
enigma\_encrypt("Hello World", "123")

Uninstall:
pip3 uninstall uu-enigma-kostas_
